import sys
import json
import os

DATA_FILE = "data.json"

def load_data():
    """Reads the JSON file and returns the data list."""
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except json.JSONDecodeError:
        print("⚠️ Warning: Data file is corrupted. Starting with an empty database.")
        return []

def save_data(data):
    """Saves the updated data list back to the JSON file."""
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=2)
        print("💾 Data saved successfully to database!")
    except Exception as e:
        print(f"❌ Error saving data: {e}")

def check_alerts(temp, humidity):
    """Logic to detect critical weather protocols."""
    if temp >= 40.0:
        print("\n🚨 ALERT PROTOCOL TRIGGERED: RED ALERT BY EXTREME HEAT! 🚨")
    elif temp <= 0.0:
        print("\n🚨 ALERT PROTOCOL TRIGGERED: FREEZING TEMPERATURE ALERT! 🚨")
    elif humidity >= 95.0:
        print("\n🚨 ALERT PROTOCOL TRIGGERED: EXTREME RAIN / FLOOD RISK! 🚨")

def consult_data(weather_records):
    """Filters records by a specific zone and displays averages."""
    print("\n--- Consult Data by Zone ---")
    if not weather_records:
        print("📭 The database is completely empty.")
        return

    target_zone = input("Enter the name of the zone to filter by (e.g., Centro, Vallecas): ").strip()
    
    # Create a sub-list of records that match the requested zone
    filtered_records = [r for r in weather_records if r["zone"].lower() == target_zone.lower()]

    if not filtered_records:
        print(f"🔍 No records found for zone: '{target_zone}'")
        return

    print(f"\n📊 Found {len(filtered_records)} records for '{target_zone}':")
    print("-" * 50)
    
    total_temp = 0.0
    total_humidity = 0.0

    for record in filtered_records:
        print(f"Date: {record['date']} | Temp: {record['temperature']}ºC | Humidity: {record['humidity']}% | Wind: {record['wind']} km/h")
        total_temp += record["temperature"]
        total_humidity += record["humidity"]
    
    print("-" * 50)
    
    # Basic Estimates (Statistical calculations required by your project)
    avg_temp = total_temp / len(filtered_records)
    avg_humidity = total_humidity / len(filtered_records)
    
    print(f"📈 STATISTICAL SUMMARY FOR {target_zone.upper()}:")
    print(f"   -> Average Temperature: {avg_temp:.2f}ºC")
    print(f"   -> Average Humidity: {avg_humidity:.2f}%")

def register_data(weather_records):
    """Asks user for data, validates it, checks for duplicates, and adds it."""
    print("\n--- Register New Weather Data ---")
    
    date = input("Enter date (YYYY-MM-DD): ").strip()
    zone = input("Enter zone/district (e.g., Centro, Vallecas): ").strip()

    for record in weather_records:
        if record["date"] == date and record["zone"].lower() == zone.lower():
            print("\n❌ Error: A record for this zone on this date already exists!")
            return 

    try:
        temp = float(input("Enter Temperature (ºC): "))
        if temp < -50 or temp > 60:
            print("❌ Validation Error: Temperature must be between -50ºC and 60ºC.")
            return

        humidity = float(input("Enter Humidity (%): "))
        if humidity < 0 or humidity > 100:
            print("❌ Validation Error: Humidity must be between 0% and 100%.")
            return

        wind = float(input("Enter Wind Speed (km/h): "))
        if wind < 0 or wind > 200:
            print("❌ Validation Error: Wind speed must be realistic (0-200 km/h).")
            return

    except ValueError:
        print("\n❌ Input Error: Please enter valid numbers for temperature, humidity, and wind.")
        return

    new_record = {
        "date": date,
        "zone": zone,
        "temperature": temp,
        "humidity": humidity,
        "wind": wind
    }

    weather_records.append(new_record)
    check_alerts(temp, humidity)
    save_data(weather_records)

def main_menu():
    weather_records = load_data()
    print(f"[System Loaded] {len(weather_records)} weather records found.")

    while True:
        print("\n=================================")
        print("  AYUNTAMIENTO WEATHER SYSTEM    ")
        print("=================================")
        print("1. Consult Data by Zone")
        print("2. Register New Weather Data")
        print("3. Exit (Salida)")
        print("=================================")
        
        choice = input("Please select an option (1-3): ").strip()
        
        if choice == "1":
            consult_data(weather_records)
        elif choice == "2":
            register_data(weather_records)
        elif choice == "3":
            print("\n[System] Closing application. ¡Hasta luego!")
            sys.exit()
        else:
            print("\n❌ Invalid choice! Please type 1, 2, or 3.")

if __name__ == "__main__":
    main_menu()